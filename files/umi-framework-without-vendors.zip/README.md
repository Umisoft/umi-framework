UMI.Framework
======

Master branch [![Build Status](https://travis-ci.org/Umisoft/umi-framework.png?branch=master)](https://travis-ci.org/Umisoft/umi-framework)

Dev branch [![Build Status](https://travis-ci.org/Umisoft/umi-framework.png?branch=dev)](https://travis-ci.org/Umisoft/umi-framework)

### УСТАНОВКА

Смотрите [INSTALL.md](INSTALL.md).

### ЛИЦЕНЗИЯ

Файлы в этом репозитории находятся под действием лицензии BSD-3 Clause.
Копия данной лицензии доступна в [LICENSE](LICENSE).
